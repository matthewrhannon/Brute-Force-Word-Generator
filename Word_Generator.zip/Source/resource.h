//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDD_DIALOG1                     101
#define IDD_DIALOG                      101
#define IDC_EDIT1                       1000
#define IDC_BUTTON1                     1001
#define IDC_GENERATE                    1001
#define IDC_CUSTOM1                     1002
#define IDC_OUTPUT                      1005
#define IDC_SEARCH                      1006
#define IDC_MAXIUMSLOTS                 1009
#define IDC_ENABLECHARSET               1012
#define IDC_CHARSET                     1013
#define IDC_RADIO4                      1014
#define IDC_RADIO5                      1015
#define IDC_RADIO6                      1016
#define IDC_CASEOPTIONS                 1019
#define IDC_STATIC2                     1021
#define IDC_STATIC3                     1022
#define IDC_STATIC4                     1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
