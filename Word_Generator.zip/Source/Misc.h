//A global header file that i use for certain cut throughs 

#ifndef MISC_H
#define MISC_H

#define PROGRAM_NAME "Brute Forcer"
#define inline __forceinline

#define MsgBox(Text) MessageBox(NULL, Text, PROGRAM_NAME, MB_OK)
#define MsgBoxError(Text) MessageBox(NULL, Text, PROGRAM_NAME, MB_STOP | MB_OK | MB_APPMODAL)

void ErrorMessage(void)
{
	char Buffer[256];

	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), 0, (LPTSTR)Buffer, 256, NULL);

	MessageBox(NULL, Buffer, PROGRAM_NAME, MB_OK);
}

#endif 