//Win32Base code by Matthew Hannon and Aaron Sorrel

#include <windows.h>
#include <stdio.h>
#include <math.h>
#include <winbase.h>

#include "Misc.h"
#include "resource.h"

char szFile[256];
char szFileTitle[256];
char szFilter[256] = "Text Files\0*.txt;*.doc\0Any Files\0*.*\0";

char Abc123[] =
{
	{'A'},
	{'B'},
	{'C'},
	{'D'},
	{'E'},
	{'F'},
	{'G'},
	{'H'},
	{'I'},
	{'J'},
	{'K'},
	{'L'},
	{'M'},
	{'N'},
	{'O'},
	{'P'},
	{'Q'},
	{'R'},
	{'S'},
	{'T'},
	{'U'},
	{'V'},
	{'W'},
	{'X'},
	{'Y'},
	{'Z'},
	{'a'},
	{'b'},
	{'c'},
	{'d'},
	{'e'},
	{'f'},
	{'g'},
	{'h'},
	{'i'},
	{'j'},
	{'k'},
	{'l'},
	{'m'},
	{'n'},
	{'o'},
	{'p'},
	{'q'},
	{'r'},
	{'s'},
	{'t'},
	{'u'},
	{'v'},
	{'w'},
	{'x'},
	{'y'},
	{'z'},
	{'0'},
	{'1'},
	{'2'},
	{'3'},
	{'4'},
	{'5'},
	{'6'},
	{'7'},
	{'8'},
	{'9'},
};
char abc123[] =
{
	{'A'},
	{'B'},
	{'C'},
	{'D'},
	{'E'},
	{'F'},
	{'G'},
	{'H'},
	{'I'},
	{'J'},
	{'K'},
	{'L'},
	{'M'},
	{'N'},
	{'O'},
	{'P'},
	{'Q'},
	{'R'},
	{'S'},
	{'T'},
	{'U'},
	{'V'},
	{'W'},
	{'X'},
	{'Y'},
	{'Z'},
	{'0'},
	{'1'},
	{'2'},
	{'3'},
	{'4'},
	{'5'},
	{'6'},
	{'7'},
	{'8'},
	{'9'},
};
/*
char abc[] =
{

/*
char abc[] =
{
	{'a'},
	{'b'},
	{'c'},
	{'d'},
	{'e'},
	{'f'},
	{'g'},
	{'h'},
	{'i'},
	{'j'},
	{'k'},
	{'l'},
	{'m'},
	{'n'},
	{'o'},
	{'p'},
	{'q'},
	{'r'},
	{'s'},
	{'t'},
	{'u'},
	{'v'},
	{'w'},
	{'x'},
	{'y'},
	{'z'},
};

char Numbers[] =
{
	{'1'},
	{'2'},
	{'3'},
	{'4'},
	{'5'},
	{'6'},
	{'7'},
	{'8'},
	{'9'},
	{'0'},
};
*/
BOOL CALLBACK WinProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	switch(Msg)
	{
		case WM_INITDIALOG:
			EnableWindow(GetDlgItem(hWnd, IDC_CHARSET), false);

			SetDlgItemInt(hWnd, IDC_MAXIUMSLOTS, 2, true);;

			SendDlgItemMessage(hWnd, IDC_CASEOPTIONS, CB_ADDSTRING, (WPARAM)0, (LPARAM)(LPCTSTR)"UpperCase");
			SendDlgItemMessage(hWnd, IDC_CASEOPTIONS, CB_ADDSTRING, (WPARAM)0, (LPARAM)(LPCTSTR)"LowerCase");
			SendDlgItemMessage(hWnd, IDC_CASEOPTIONS, CB_ADDSTRING, (WPARAM)0, (LPARAM)(LPCTSTR)"Both");

			CheckDlgButton(hWnd, IDC_RADIO6, true);

			SetDlgItemText(hWnd, IDC_OUTPUT, "Output.txt");

			ShowWindow(GetDlgItem(hWnd, IDC_STATIC2), false);
			ShowWindow(GetDlgItem(hWnd, IDC_STATIC3), false);
			ShowWindow(GetDlgItem(hWnd, IDC_STATIC4), false);
		return TRUE;

		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDC_ENABLECHARSET:
					if(IsDlgButtonChecked(hWnd, IDC_ENABLECHARSET))
					{
						EnableWindow(GetDlgItem(hWnd, IDC_CHARSET), true);
						EnableWindow(GetDlgItem(hWnd, IDC_RADIO4), false);
						EnableWindow(GetDlgItem(hWnd, IDC_RADIO5), false);
						EnableWindow(GetDlgItem(hWnd, IDC_RADIO6), false);
						EnableWindow(GetDlgItem(hWnd, IDC_CASEOPTIONS), false);
					}

					else
					{
						EnableWindow(GetDlgItem(hWnd, IDC_CHARSET), false);
						EnableWindow(GetDlgItem(hWnd, IDC_RADIO4), true);
						EnableWindow(GetDlgItem(hWnd, IDC_RADIO5), true);
						EnableWindow(GetDlgItem(hWnd, IDC_RADIO6), true);
						EnableWindow(GetDlgItem(hWnd, IDC_CASEOPTIONS), true);
					}
				return TRUE;

				case IDC_SEARCH:
					OPENFILENAME ofn;
 
					szFile[0] = '\0';
 
					memset(&ofn, 0, sizeof(OPENFILENAME));
 
					ofn.lStructSize       = sizeof(OPENFILENAME);
					ofn.hwndOwner         = NULL;
					ofn.lpstrFilter       = szFilter;
					ofn.nFilterIndex      = 1;
					ofn.lpstrFile         = szFile;
					ofn.nMaxFile          = sizeof(szFile);
					ofn.lpstrFileTitle    = szFileTitle;
					ofn.nMaxFileTitle     = sizeof(szFileTitle);
					ofn.lpstrInitialDir   = NULL;
					ofn.Flags             = OFN_HIDEREADONLY;

					if(GetSaveFileName(&ofn)) 
					{
						if(szFile[strlen(szFile)-1] != 't')
							strcat(szFile, ".txt");
						
						SetDlgItemText(hWnd, IDC_OUTPUT, szFile);
					}

				return TRUE;

				case IDC_GENERATE:

					//its called a thread you IDIOT
					SetWindowText(hWnd, "Loading: Please Dont do anything, dont touch application");
					
					char Output[256];
					char CharBuff[256];
					
					int Max;
					int Caps, Both;

					int CharSet;

					CharSet = 0;

					int b;

					b = 0;

					int Number;

					Number = 0;

					GetDlgItemText(hWnd, IDC_OUTPUT, Output, 256);

					Max = GetDlgItemInt(hWnd, IDC_MAXIUMSLOTS, false, false);

					Caps = SendDlgItemMessage(hWnd, IDC_CASEOPTIONS, CB_GETCURSEL, 0, 0);

					if(BST_CHECKED == IsDlgButtonChecked(hWnd, IDC_RADIO4))
						Both = 1;
					else if(BST_CHECKED == IsDlgButtonChecked(hWnd, IDC_RADIO5))
						Both = 2;
					else if(BST_CHECKED == IsDlgButtonChecked(hWnd, IDC_RADIO6))
						Both = 3;
				
					if(BST_CHECKED == IsDlgButtonChecked(hWnd, IDC_ENABLECHARSET))
						CharSet = 1;

					GetDlgItemText(hWnd, IDC_CHARSET, CharBuff, 256);

				//	if(Both == 1)
					//	Max++;

					FILE *File;

					File = fopen(Output, "wt");
					File = fopen(Output, "a+");

					CreateDirectory("Temp", NULL);

					FILE *Temp;
					FILE *Temp1;

					Temp = fopen("Temp\\Temp.txt", "wt");
					Temp1 = fopen("Temp\\Temp1.txt", "wt");	

					char Buffer[16];
					char Buffer1[16];

					int In;

					In = 0;

					Number = 0;
					
					if(Caps == 2)
						Number = 26;
					else if(Caps == 1)
						Number = 52;
					else if(Caps == 0)
						Number = 52;

					if(Both == 3)
					{
						Number += 10;
					}

					if(Both == 1)
					{
						Number = 62;
					}

					if(Max > 0)
					{
						
						if(Caps == 1)
							b = 26;
						else if(Caps == 0)
							b = 0;
						else if(Caps == 2)
							b = 0;

						if(Both == 1)
							b = 52;

						if(CharSet == 1)
						{
							b = 0;
							Number = strlen(CharBuff);
						}

						for(int y = b; y<Number; y++)
						{		
							if(CharSet != 1)
								sprintf(Buffer, "%c\n", Abc123[y]);		
							else
								sprintf(Buffer, "%c\n", CharBuff[y]);

							if(Both == 3 && Caps == 2)
								sprintf(Buffer, "%c\n", abc123[y]);
					
							fputs(Buffer, Temp1);
						}

						fclose(Temp1);
						

	
						
						ShowWindow(GetDlgItem(hWnd, IDC_STATIC3), true);
						ShowWindow(GetDlgItem(hWnd, IDC_STATIC2), true);
						ShowWindow(GetDlgItem(hWnd, IDC_STATIC4), true);
						
						SetDlgItemText(hWnd, IDC_STATIC2, "Loading..Please Hold.");
						SetDlgItemText(hWnd, IDC_STATIC4, "Word:");

						if(Max > 1)
						{
							for(int x = 0; x<Max-1; x++)
							{
								fclose(Temp1);
								CopyFile("Temp\\Temp1.txt", "Temp\\Temp.txt", false);

								Temp1 = fopen("Temp\\Temp1.txt", "wt");
								
								strcpy(Buffer, "");
								
								fclose(Temp);
								Temp = fopen("Temp\\Temp.txt", "r");
								
								while(!feof(Temp))
								{
									fgets(Buffer, 16, Temp);
	
									if(Buffer[strlen(Buffer)-1] == '\n')
										Buffer[strlen(Buffer)-1] = '\0';
								
									sprintf(Buffer, "%s\n", Buffer);
									fputs(Buffer, File);
								}

								fclose(Temp);
								Temp = fopen("Temp\\Temp.txt", "r");
 
								while(!feof(Temp))
								{
									fgets(Buffer1, 16, Temp);

									if(Buffer1[strlen(Buffer1)-1] == '\n')
										Buffer1[strlen(Buffer1)-1] = '\0';
	
									for(int z = b; z<Number; z++)
									{
										strcpy(Buffer, "");
										sprintf(Buffer, "%s%c\n", Buffer1, Abc123[z]);
									
										if(CharSet != 1)
											sprintf(Buffer, "%s%c\n", Buffer1, Abc123[z]);	
										else
											sprintf(Buffer, "%s%c\n", Buffer1, CharBuff[z]);

										if(Both == 3 && Caps == 2)
											sprintf(Buffer, "%s%c\n", Buffer1, abc123[z]);
										
										SetDlgItemText(hWnd, IDC_STATIC3, Buffer);

										fputs(Buffer, Temp1);
									}
								}
												
							 }
						}

						strcpy(Buffer, "");
								
						fclose(Temp1);
						Temp1 = fopen("Temp\\Temp1.txt", "r");
							
						while(!feof(Temp1))
						{
							fgets(Buffer, 16, Temp1);

							if(Buffer[strlen(Buffer)-1] == '\n')
								Buffer[strlen(Buffer)-1] = '\0';
								
							sprintf(Buffer, "%s\n", Buffer);

							fputs(Buffer, File);
						}
					}
					
					fclose(File);
					fclose(Temp);
					fclose(Temp1);

					remove("Temp\\Temp.txt");
					remove("Temp\\Temp1.txt");

					RemoveDirectory("Temp");

					SetDlgItemText(hWnd, IDC_STATIC2, "Loading Complete");
			
				return TRUE;

			}
		return TRUE;

		case WM_CLOSE:
			PostQuitMessage(0);
		return TRUE;

		case WM_DESTROY:
			PostQuitMessage(0);
		return TRUE;
	}
	
	return FALSE;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, char *lpszCmdLine, int nCmdShow)
{
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)WinProc);

	return true;
}

